public class CC02 {

  String remove1(char c, String s) {
    return "";
  }


  boolean ab(String s) {
    return false;
  }
    

  String reverse(String s) {
    return "";
  }

  boolean startsWith(String s1, String s2) {
    return false;
  }

  boolean contains(String s1, String s2) {
    return false;
  }

  String reverseWords(String s) {
    return "";
  }

}
