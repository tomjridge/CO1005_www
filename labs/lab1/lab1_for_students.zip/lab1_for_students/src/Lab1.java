public class Lab1 {

  String f () {
    return "";
  }
  

  int sum(int x, int y) {
    return -1;
  }

  boolean fizz(int x, int y) {
    return false;
  }

  int cop(int x, int y) {
    return -1;
  }

}
