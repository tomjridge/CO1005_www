import java.util.*;

class Lab7 {

  public static void main(String[] args) {
    Comparator c = new Comparator() {
        public int compare(Object o1, Object o2) {
          String s1 = ((String)o1).substring(1);
          String s2 = ((String)o2).substring(1);
          return s1.compareTo(s2);
        }
      };
    String[] arr = {"first","second","third","firtree"};
    List l = Arrays.asList(arr);
    Collections.sort(l,c);
    System.out.println(l);

    Comparator d = new Comparator() {
        public int compare(Object o1, Object o2) {
          String s1 = ((String)o1);
          String s2 = ((String)o2);
          s1 = s1.substring(1+s1.indexOf(" "));
          s2 = s2.substring(1+s2.indexOf(" "));
          return s1.compareTo(s2);
        }
      };
    String[] arr2 = {"alf michaels", "bert koala", "charlie pickes"};
    l = Arrays.asList(arr2);
    Collections.sort(l,d);
    System.out.println(l);
    
    
  }

}
