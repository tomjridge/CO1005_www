import java.util.*;

// mergesort class ----------------------------------------


public class MergeSort<T> extends List_ops<T> { // bring in hd, tl etc
  
  // generic functions ----------------------------------------

  int length(List<T> l) {
    int to_return = 0;
    while(true) {
      if(l.isEmpty()) return to_return;
      l=tl(l);
      to_return++;
    }
  }

  // return first n elts
  List<T> take(int n, List<T> l) {
    List<T> to_return = nil();
    while(true) {
      if(length(to_return) == n) return to_return;
      to_return = append1(to_return,hd(l));
      l = tl(l);
    }
  }

  // drop first n elts
  List<T> drop(int n, List<T> l) {
    List<T> to_drop = nil();
    while(true) {
      if(length(to_drop) == n) return l;
      to_drop = append1(to_drop,hd(l));
      l = tl(l);
    }
  }

  // merge two sorted lists of ints
  List<T> merge(Comparator<T> c, List<T> l1, List<T> l2) {
    List<T> to_return = nil();
    while(true) {
      if(l1.isEmpty()) return append(to_return,l2);
      if(l2.isEmpty()) return append(to_return,l1);
      T i1 = hd(l1);
      T i2 = hd(l2);
      if(c.compare(i1,i2) <= 0) { // FIXME
        to_return = append1(to_return,i1);
        l1 = tl(l1);
      } else {
        to_return = append1(to_return,i2);
        l2 = tl(l2);
      }
    }
  }

  // mergesort! ----------------------------------------

  List<T> mergesort(Comparator<T> c, List<T> l) {
    if(length(l) == 0 || length(l)==1) return l; // already sorted
    List<T> l1 = take(length(l)/2,l); // first half
    List<T> l2 = drop(length(l)/2,l); // second half
    l1 = mergesort(c,l1);  // sort l1
    l2 = mergesort(c,l2);  // sort l2
    return merge(c,l1,l2);  // merge l1 and l2
  }

  // testing ---------------------------------------- 

  void print(String s) {
    System.out.println(s);
  } 

  public static void main(String[] args) {
    Comparator c = new Comparator<String>() {
        public int compare(String s1, String s2) {
          return -1 * s1.compareTo(s2);
        }
      };
    String[] arr = { "charlie","alf","bert" };
    List<String> l = Arrays.asList(arr);
    MergeSort<String> ms = new MergeSort();
    System.out.println(ms.mergesort(c,l));
  }

}



