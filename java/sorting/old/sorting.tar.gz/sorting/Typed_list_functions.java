////////////////////////////////////////
import java.util.*;

// hd, tl etc; typed
class Typed_list_functions<E> {

  public List<E> copy(List<E> l0) {
    List to_return = new LinkedList();
    for(int i=0; i<l0.size(); i++) {
      to_return.add(i,l0.get(i));
    }
    return to_return;
  }

  // the empty list
  public List<E> nil() {
    return new LinkedList<E>();
  }

  // add at front of list
  public List<E> cons(E o, List<E> l0) {
    List l = copy(l0);
    l.add(0,o);
    return l;
  }


  // head of the list
  public E hd(List<E> l) { return l.get(0); }

  // tail of the list
  public List<E> tl(List<E> l0) {
    List l = copy(l0);
    l.remove(0);
    return l;
  }

  // add at end of list
  public List<E> append1(List<E> l0, E o) {
    List l = copy(l0);
    l.add(l.size(),o);
    return l;
  }

  // join two lists together
  public List<E> append(List<E> l01, List<E> l02) {
    List<E> to_return = copy(l01);
    List<E> l2 = copy(l02);

    while(true) {
      if(l2.isEmpty()) return to_return;
      to_return=append1(to_return,hd(l2));
      l2=tl(l2);
    }

  }

  public String list_to_string(List l) {
    String to_return ="[";
    while(true) {
      if(l.isEmpty()) return (to_return+"]");
      if(tl(l).isEmpty()) return (to_return+hd(l)+"]");
      to_return+=hd(l)+",";
      l=tl(l);
    }
  }
} // Typed_list_functions
