////////////////////////////////////////
import java.util.*;

public class Typed_ins_sort<E,L> {

  Typed_ops<E,L> ops;
  

  public Typed_ins_sort(Typed_ops<E,L> ops) {
    this.ops = ops;
  }

  
  L insert(E o, L l) {
    L to_return = ops.i_nil();
    while(true) {
      if(ops.i_is_empty(l)) return ops.i_append1(to_return,o);
      E o2 = ops.i_hd(l);
      if(ops.i_lt(o2,o)) to_return = ops.i_append1(to_return,o2);
      else { return 
          ops.i_append(ops.i_append1(to_return,o),l); }
      l = ops.i_tl(l);
    }
  }

  
  L ins_sort(L l) {
    L to_return = ops.i_nil();
    while(true) {
      if(ops.i_is_empty(l)) return to_return;
      E o = ops.i_hd(l);
      to_return = insert(o,to_return);
      l = ops.i_tl(l);
    }
  }

  
}
