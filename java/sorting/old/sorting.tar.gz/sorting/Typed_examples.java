////////////////////////////////////////
import java.util.*;

public class Typed_examples {

  static void print(Object s) {
    System.out.println(s.toString());
  }

  // extend abstract class, define abstract method
  static class Double_ops 
    extends Typed_list_ops<Double> 
  {
    public boolean i_lt(Double i1, Double i2) {
      return i1 < i2;
    }
  };


  // extend abstract class, define abstract method
  static class Integer_ops 
    extends Typed_list_ops<Integer> 
  {
    public boolean i_lt(Integer i1, Integer i2) {
      return i1 < i2;
    }
  };
  

  public static void main(String[] args) {
    // sort a string
    {
      Typed_ins_sort<Character,String> s1 = 
        new Typed_ins_sort<Character,String>(
          new Typed_string_ops());
      print(s1.ins_sort("deabc"));
    }

    // sort a list of integers
    {
      Typed_list_ops<Integer> ops = new Integer_ops();

      Typed_ins_sort<Integer,List<Integer>> ist = 
        new Typed_ins_sort<Integer,List<Integer>>(ops);

      print(ist.ins_sort(Arrays.asList(
        new Integer[] { 4,5,6,3,2,1 })));
    }

    // sort a list of integers in reverse
    {
      Typed_list_ops<Integer> ops = 
        // extend abstract class, define abstract method
        new Typed_list_ops<Integer>() {
          public boolean i_lt(Integer i1, Integer i2) {
            return i1 > i2;
          }
        };

      Typed_ins_sort<Integer,List<Integer>> ist = 
        new Typed_ins_sort<Integer,List<Integer>>(ops);

      print(ist.ins_sort(Arrays.asList(
        new Integer[] { 4,5,6,3,2,1 })));
    }

  }

}
