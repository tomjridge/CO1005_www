////////////////////////////////////////
public interface Typed_ops<E,L> {

  boolean i_lt(E o1, E o2);

  L i_nil();
  L i_cons(E x, L l);
  L i_append(L l1, L l2);
  L i_append1(L l, E e);

  boolean i_is_empty(L l);
  E i_hd(L l);
  L i_tl(L l);

}
