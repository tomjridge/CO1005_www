////////////////////////////////////////
// implement the interface for strings
public class Typed_string_ops 
  implements Typed_ops<Character,String> 
{

  public boolean i_is_empty(String l) {
    return l.equals("");
  }

  public Character i_hd(String l) {
    return l.charAt(0);
  }

  public String i_tl(String l) {
    return l.substring(1);
  }

  public String i_append(String l1,String l2) {
    return l1+l2;
  }

  public String i_append1(String l1, Character e) {
    return l1+e;
  }

  public boolean i_lt(Character o1,Character o2) {
    return o1 < o2;
  }

  public String i_nil() { return ""; }

  public String i_cons(Character x, String l) {
    return x.toString()+l;
  }    

} 



