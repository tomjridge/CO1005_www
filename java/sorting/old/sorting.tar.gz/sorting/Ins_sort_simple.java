////////////////////////////////////////
import java.util.*;

public class Ins_sort_simple {

  Ins_sort_ops ops;
  

  public Ins_sort_simple(Ins_sort_ops ops) {
    this.ops = ops;
  }

  
  Object insert(Object o, Object l) {
    Object to_return = ops.i_nil();
    while(true) {
      if(ops.i_is_empty(l)) return ops.i_append1(to_return,o);
      Object o2 = ops.i_hd(l);
      if(ops.i_lt(o2,o)) { to_return = ops.i_append1(to_return,o2); }
      else { return ops.i_append(ops.i_append1(to_return,o),l); }
      l = ops.i_tl(l);
    }
  }

  
  Object ins_sort(Object l) {
    Object to_return = ops.i_nil();
    while(true) {
      if(ops.i_is_empty(l)) return to_return;
      Object o = ops.i_hd(l);
      to_return = insert(o,to_return);
      l = ops.i_tl(l);
    }
  }

  
  static void print(Object s) {
    System.out.println(s.toString());
  }
  
  public static void main(String[] args) {
    // sort a string
    Ins_sort_simple s1 = new Ins_sort_simple(new String_ops());
    print(s1.ins_sort("deabc"));
    Ins_sort_simple s2 = new Ins_sort_simple(new List_ops());
    print(s2.ins_sort(Arrays.asList(new Integer[] { 4,5,6,3,2,1 })));
  }



  
  // implement the interface for strings
  static class String_ops implements Ins_sort_ops {
    public boolean i_is_empty(Object l) {
      return ((String)l).equals("");
    }

    public Object i_hd(Object l) {
      return ((String)l).charAt(0);
    }

    public Object i_tl(Object l) {
      return ((String)l).substring(1);
    }

    public Object i_append(Object l1,Object l2) {
      return ((String)l1)+((String)l2);
    }

    public Object i_append1(Object l1, Object e) {
      return ((String)l1)+((char)e);
    }

    public boolean i_lt(Object o1,Object o2) {
      return ((char)o1) < ((char)o2);
    }

    public Object i_nil() { return ""; }

    public Object i_cons(Object x, Object l) {
      return ((char)x)+((String)l);
    }    
  }



  
  
  // implement the interface for Lists of ints
  static class List_ops implements Ins_sort_ops {

    public boolean i_lt(Object o1,Object o2) {
      return ((Integer)o1) < ((Integer)o2);
    }
    
    public boolean i_is_empty(Object l) {
      return ((List)l).isEmpty();
    }

    
    public Object i_hd(Object l) {
      return hd((List)l);
    }

    public Object i_tl(Object l) {
      return tl((List)l);
    }

    public Object i_append(Object l1,Object l2) {
      return append((List)l1,(List)l2);
    }

    public Object i_append1(Object l1, Object e) {
      return append1((List)l1,(Integer)e);
    }


    public Object i_nil() { return nil(); }

    public Object i_cons(Object x, Object l) {
      return cons((Integer)x,((List)l));
    }
    

  //////////////////////////////////////////////////////////////////////
  // cons, nil etc are implemented below this line;
  // you can probably ignore what is below
  
  // most of the following methods could/should be static

  // clone is protected, so we could subclass but...  YOU ARE NOT
  // ALLOWED TO USE THIS FUNCTION!!! IT IS ONLY FOR IMPLEMENTING cons
  // ETC.
  public List copy(List l0) {
    List to_return = new LinkedList();
    for(int i=0; i<l0.size(); i++) {
      to_return.add(i,l0.get(i));
    }
    return to_return;
  }

  // the empty list
  public List nil() {
    return new LinkedList();
  }

  // add at front of list
  public List cons(Object o, List l0) {
    List l = copy(l0);
    l.add(0,o);
    return l;
  }


  // head of the list
  public Object hd(List l) { return l.get(0); }

  // tail of the list
  public List tl(List l0) {
    List l = copy(l0);
    l.remove(0);
    return l;
  }

  // add at end of list
  public List append1(List l0, Object o) {
    List l = copy(l0);
    l.add(l.size(),o);
    return l;
  }

  // join two lists together
  public List append(List l01, List l02) {
    List to_return = copy(l01);
    List l2 = copy(l02);

    while(true) {
      if(l2.isEmpty()) return to_return;
      to_return=append1(to_return,hd(l2));
      l2=tl(l2);
    }

  }

  String list_to_string(List l) {
    String to_return ="[";
    while(true) {
      if(l.isEmpty()) return (to_return+"]");
      if(tl(l).isEmpty()) return (to_return+hd(l)+"]");
      to_return+=hd(l)+",";
      l=tl(l);
    }
  }
    
  }

  

  
}
