////////////////////////////////////////
import java.util.*;

abstract class Typed_list_ops<E>
  extends Typed_list_functions<E>  // for hd, tl etc
  implements Typed_ops<E,List<E>>  // what we provide below
{

  public boolean i_is_empty(List<E> l) {
    return l.isEmpty();
  }
    
  public E i_hd(List<E> l) {
    return hd(l);
  }

  public List<E> i_tl(List<E> l) {
    return tl(l);
  }

  public List<E> i_append(List<E> l1,List<E> l2) {
    return append(l1,l2);
  }

  public List<E> i_append1(List<E> l1, E e) {
    return append1(l1,e);
  }

  public List<E> i_nil() { return nil(); }

  public List<E> i_cons(E x, List<E> l) {
    return cons(x,l);
  }

  // but what do we do here? 
  // we don't know the order on E, so we use
  // an *abstract* class
  public abstract boolean i_lt(E o1,E o2);
        
} // Typed_list_ops; needs list operations


