////////////////////////////////////////
public interface Ins_sort_ops {

  boolean i_lt(Object o1, Object o2);

  Object i_nil();
  Object i_cons(Object x, Object l);
  Object i_append(Object l1, Object l2);
  Object i_append1(Object l, Object e);

  boolean i_is_empty(Object l);
  Object i_hd(Object l);
  Object i_tl(Object l);

}
