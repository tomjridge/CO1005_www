import java.util.*;

public class MergeSort {

  List merge(List l1, List l2) {
    List to_return = nil();
    while(true) {
      if(l1.isEmpty()) return append(to_return,l2);
      if(l2.isEmpty()) return append(to_return,l1);
      Integer i1 = (Integer)(hd(l1));
      Integer i2 = (Integer)(hd(l2));
      if(i1 < i2) {
        to_return = append1(to_return,i1);
        l1 = tl(l1);
      } else {
        to_return = append1(to_return,i2);
        l2 = tl(l2);
      }
    }
  }

  int length(List l) {
    int to_return =0;
    while(true) {
      if(l.isEmpty()) return to_return;
      l=tl(l);
      to_return++;
    }
  }

  List split1(List l0) {
    List to_return = nil();
    List l = l0;
    while(true) {
      if(length(to_return) == length(l0)/2) return to_return;
      to_return = append1(to_return,hd(l));
      l = tl(l);
    }
  }

  List split2(List l0) {
    List to_return = nil();
    List l = l0;
    while(true) {
      if(length(to_return) == length(l0)/2) return l; // NB change
      to_return = append1(to_return,hd(l));
      l = tl(l);
    }
  }

  List mergesort(List l) {
    if(length(l) == 0) return l; // already sorted
    if(length(l) == 1) return l; // already sorted
    List l1 = split1(l);
    List l2 = split2(l);
    l1 = mergesort(l1);
    l2 = mergesort(l2);
    return merge(l1,l2);
  }

  void print(String s) {
    System.out.println(s);
  } 

  void main() { 
    List l123=cons(1,cons(2,cons(3,nil())));
    List l456=cons(4,cons(5,cons(6,nil())));
    List l456123 = append(l456,l123);
    print(asString(l456123));
    print(asString(mergesort(l456123)));
  }

  public static void main(String[] args) {
    new MergeSort().main(); // run main functions
  }



  //////////////////////////////////////////////////////////////////////
  // ALLLIST

  // most of the following methods could/should be static

  // clone is protected, so we could subclass but...  YOU ARE NOT
  // ALLOWED TO USE THIS FUNCTION!!! IT IS ONLY FOR IMPLEMENTING cons
  // ETC.
  List copy(List l0) {
    List to_return = new LinkedList();
    for(int i=0; i<l0.size(); i++) {
      to_return.add(i,l0.get(i));
    }
    return to_return;
  }

  // the empty list
  List nil() {
    return new LinkedList();
  }

  // add at front of list
  List cons(Object o, List l0) {
    List l = copy(l0);
    l.add(0,o);
    return l;
  }


  // head of the list
  Object hd(List l) { return l.get(0); }

  // tail of the list
  List tl(List l0) {
    List l = copy(l0);
    l.remove(0);
    return l;
  }

  // add at end of list
  List append1(List l0, Object o) {
    List l = copy(l0);
    l.add(l.size(),o);
    return l;
  }

  // join two lists together
  List append(List l01, List l02) {
    List to_return = copy(l01);
    List l2 = copy(l02);

    while(true) {
      if(l2.isEmpty()) return to_return;
      to_return=append1(to_return,hd(l2));
      l2=tl(l2);
    }

  }

  // for debugging
  String asString(List l) {
    String to_return ="[";
    while(true) {
      if(l.isEmpty()) return (to_return+"]");
      if(tl(l).isEmpty()) return (to_return+hd(l)+"]");
      to_return+=hd(l)+",";
      l=tl(l);
    }
  }


}
